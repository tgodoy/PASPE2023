##############################################################################
#########                          PASPE 2023                        #########
#########      Analisis de datos de Ciencias Genomicas usando R      #########   
######       E. Ernestina Godoy Lozano (elizabeth.godoy@insp.mx)     #########
######                       Bitacora de comandos                    #########
######    UNIDAD 2. Bioconductor para analisis de secuencias cortas  #########
######          Secuencias, Alineamientos y Operaciones basicas      #########
##############################################################################

# Texto sin acentos

# Posicionarse en su directorio de trabajo
setwd("~/PASPE_2023_Datos_genomicos_R/2.Bioconductor")
getwd()

# Cargar librerias de trabajo
library(ShortRead)

# visualizar las librerias que son dependencias de ShortRead
sessionInfo()

# Cargar funcion plotRanges()
plotRanges <- function(x, xlim = x, main = deparse(substitute(x)),
                       col = "dodgerblue", sep = 0.5, ...)
{
  height <- 1
  if (is(xlim, "Ranges"))
    xlim <- c(min(start(xlim)), max(end(xlim)))
  bins <- disjointBins(IRanges(start(x), end(x) + 1))
  plot.new()
  plot.window(xlim, c(0, max(bins)*(height + sep)))
  ybottom <- bins * (sep + height) - height
  rect(start(x)-0.5, ybottom, end(x)+0.5, ybottom + height, col = col, ...)
  title(main)
  axis(1)
}


##### IRanges
### Ejercicio 1. Generacion de objetos de IRanges
library(IRanges)
chr2 <- IRanges(start=3,end=54)
chr2

# Tipo de objeto
class(chr2)

# Inicio del rango
start(chr2)

# Final del rango
end(chr2)

# ancho del rango
width(chr2)

# Podemos solo especificar el ancho del rango y el inicio, sin el termino del rango
chr3 <- IRanges(start=5, width=20)
chr3

### Multiples rangos
chrs <-IRanges(start=c(2,10,6,14,15,18,23), width=c(12,5,6,6,7,2,3))
chrs

# Longitud de mi objeto chrs
length(chrs)

# Añadir nombres a los rangos
names(chrs) <- paste("Chr", 1:7, sep="_")
chrs

#Generar grafico
plotRanges(chrs)

#guardar la imagen
png ("figuras/ranges_chrs.png", width=300*8, height=300*6, res=300, units="px")
plotRanges(chrs)
dev.off()

### Ejercicio 2. Subsets de rangos
# Valores subsecuentes
chrs[2:4]

# Valores salteados
chrs[c(1,6,3)]

### Ejercicio 3. Manejo de objetos IRanges
# Eliminar redundancia
reduce(chrs)

# Añadir o disminuir el ancho de los rangos con los operadores - y +
chrs + 2
chrs - 1

# Desplazar los rangos por un factor 
shift(chrs, 10) 

# Encontrar sobrelapamientos
findOverlaps(chrs)

# Cobertura
coverage(chrs)

# Separacion de los rangos
disjoin(chrs)

# Generar plot de disjoin
plotRanges(disjoin(chrs))

#guardar la imagen
png ("figuras/disjoin.png", width=300*8, height=300*6, res=300, units="px")
plotRanges(disjoin(chrs))
dev.off()

# Encontrar los gaps
gaps(chrs)

# Generar plot de gaps
plotRanges(gaps(chrs))

# guardar la imagen
png ("figuras/gaps.png", width=300*8, height=300*6, res=300, units="px")
plotRanges(gaps(chrs))
dev.off()

##### GenomicRanges
library(GenomicRanges)

# Ejercicio 4. Generacion de objetos de GenomicRanges
gr <- GRanges(seqnames = "chr1", strand = c("+", "-", "+"), ranges = IRanges(start = c(1,3,5), width = 3))

# Tipo de objeto
class(gr)

# Añadir metadatos
values(gr) <- DataFrame(score = c(0.1, 0.5, 0.3), GC_content=c(50, 34, 45))
gr
plotRanges(gr)

# Acceder a los metadatos
gr$score

# Realizar operaciones con los metadatos
gr$score2 <- gr$score*2
gr

# Ejercicio 5. Manejo de objetos GenomicRanges
gr2 <- GRanges(seqnames = c("chr1", "chr4", "chr5"), strand = c("-", "-", "+"), ranges = IRanges(start = c(3,1,7), width = 4), score= c(0.2,0.3, 0.5))
plotRanges(gr2)

# nombres de las secuencias
seqnames(gr2)

# Rangos de las secuencias
ranges(gr2)

# Cadenas de las secuencias
strand(gr2)

# Otra manera de acceder a los metadatos (columnas extras)
mcols(gr2)
mcols(gr2)$score

# Sobrelapamientos
findOverlaps(gr, gr2)
subsetByOverlaps(gr, gr2)

# Generar un objeto GenomicRanges de un data frame
df <- data.frame(chr = "chr1", start = 1:3, end = 4:6, score = 7:9)
makeGRangesFromDataFrame(df)

makeGRangesFromDataFrame(df, keep.extra.columns = TRUE)

##### Biostrings
library(Biostrings)

# Variables para generar secuencias al azar
DNA_ALPHABET
AA_ALPHABET

# Ejercicio 6. Creacion y manejo de objetos en Biostrings
# Generacion de secuencia con la variable DNA_ALPHABET
seq <- sample(DNA_ALPHABET[1:4], size = 24, replace = TRUE)
seq
class(seq)

seq <- DNAString(paste(seq, collapse= ""))
seq
class(seq)

# Frecuencia de las bases
# Frecuencia absoluta
alphabetFrequency(seq, baseOnly=TRUE, as.prob=FALSE)
letterFrequency(seq, "A")
letterFrequency(seq, "GC")

# Frecuencia relativa
alphabetFrequency(seq, baseOnly=TRUE, as.prob=TRUE)
letterFrequency(seq, "A", as.prob=TRUE)
letterFrequency(seq, "GC", as.prob=TRUE)

# Longitud
length(seq)

# Acceso a bases individuales. Obtener la base numero 4 de mi secuencia "seq"
seq[4]

# Acceso a una parte de la secuencia; con un rango
seq[4:13]

# Ejercicio 7. Transformaciones basicas
# Reverso 
rev(seq)

# complemento
complement(seq)

# Reverso complementario
reverseComplement(seq)

# Traduccion
translate(seq)

# juntar las funciones
translate(reverseComplement(seq))


# Ejercicio 8. Subsets de secuencias
# Crear un objeto de mas de una secuencia

library(ShortRead)

set_seq <- NULL
for(i in 1:4){
	set_seq <- c(set_seq, paste(sample(DNA_ALPHABET[1:4], 30, replace= T), collapse = ""))
}

set_seq
set_seq <- DNAStringSet(set_seq)
names(set_seq) <- c(paste("Seq", seq(1,4,1), sep="_"))
set_seq

# Longitud de las secuencias en un objeto con mas de una secuencia
length(set_seq)
width(set_seq)
nchar(set_seq)

# nombres de las secuencias
names(set_seq)

# Acceder a las secuencias de mi objeto DNAStringSet
# una secuencia
set_seq[1]
# mas de una secuencia
set_seq[c(3,1,4)]

# subset con un rango (inicio y final de la secuencia)
subseq(set_seq, start=3, end=10)

# subset con un inicio o un final
subseq(set_seq, start=5)
subseq(set_seq, end=20)

# Ejercicio 9. Frecuencias absolutas y relativas
# Frecuencia de bases por cada secuencia
alphabetFrequency(set_seq, baseOnly=TRUE, as.prob=TRUE)

# Frecuencia de bases totales
alphabetFrequency(set_seq, baseOnly=TRUE, as.prob=TRUE, collapse=T)
letterFrequency(set_seq, "GC", as.prob=TRUE)

# Ejercicio 10. Lectura y escritura de fastas
secuencias <- readDNAStringSet("raw_data/alkB1.fa") 

# explorar objeto
secuencias
length(secuencias)

# Distribucion de las longitudes de las secuencias
hist(width(secuencias), breaks = 20, col="gold")

# Escritura de fastas
secuencias2 <- secuencias[c(1,2,5)]
writeXStringSet(secuencias2, "raw_data/alkB1_3seq.fa", format="fasta")
dir("raw_data")

# Ejercicio 11. Busqueda de patrones
# Encontar un patron
EcoRI <- DNAString("GAATTC")
matches <- vmatchPattern(EcoRI, secuencias2)
matches

# Conteo de patrones
# Contenido de GC
letterFrequency(secuencias, "GC", as.prob=TRUE)

frecuenciasGC = vcountPattern("CG", secuencias) / width(secuencias)
frecuenciasAT = vcountPattern("AT", secuencias) / width(secuencias)

b <- seq(0, 0.15, length = 30)
hist(frecuenciasGC, col = "red", xlim = c(0, 0.25), breaks = b, main = "Frequencies of CG content")
hist(frecuenciasAT, col = "green4", add = T, breaks = b)
legend("topright", c("GC content", "AT content"), fill = c("red", "green4"))


#guardar la imagen
png ("figuras/frqCG_AT.png", width=300*8, height=300*6, res=300, units="px")
hist(frecuenciasGC, col = "red", xlim = c(0, 0.25), breaks = b, main = "Frequencies of CG content")
hist(frecuenciasAT, col = "green4", add = T, breaks = b)
legend("topright", c("GC content", "AT content"), fill = c("red", "green4"))
dev.off()

# Ejercicio 12. Alineamientos de secuencias 
# pairwiseAlignment
s1 <- subseq(secuencias[1], start=3, width=40)
s2 <- subseq(secuencias[2], start=1, width=30)

# Crear una matrix de sustitucion de nucleotidos
mat <- nucleotideSubstitutionMatrix(match = 1, mismatch = -3, baseOnly = TRUE)

aln_global <- pairwiseAlignment(s1, s2, substitutionMatrix = mat, gapOpening = 5, gapExtension = 2)
aln_global
aln_local <- pairwiseAlignment(s1, s2, type = "local", substitutionMatrix = mat, gapOpening = 5, gapExtension = 2)
aln_local
aln_overlap <- pairwiseAlignment(s1, s2, type = "overlap", substitutionMatrix = mat, gapOpening = 5, gapExtension = 2)
aln_overlap


# Ejercicio 13. Trabajando con rBLAST
library(rBLAST)
# Cargar las secuencias Query
seq <- readDNAStringSet("raw_data/secuencias16S.fa")
seq

# Cargar la base de datos
bl <- blast(db="/usr/local/database/16SMicrobial/16SMicrobial")

# Alineamiento local con BLAST de 1 secuencia con un filtro de 99% identidad
cl <- predict(bl, seq[1,], BLAST_args = "-perc_identity 99")
cl

## Desplegar ayuda de BLAT
blast_help(type = "blastn")


# Alineamiento con opciones de BLAST especificas
resultados <- predict(bl, seq,
                      BLAST_args = c("-perc_identity 99", "-evalue 0.0000001"),
                      custom_format = "qseqid sseqid pident bitscore evalue length stitle")
resultados


####### ShortRead 
# Ejercicio 14.
# Lectura de fastq
fastq<- readFastq ("raw_data/antibodies.fastq")
fastq

# muestreo aleatorio
subset_fastq <- sample(fastq, 1000)
subset_fastq

# acceder a un numero determinado de secuencias
subset_fastq <- fastq[1:500]
subset_fastq

subset_fastq <- fastq[c(1:20, 30:500, 3000)]

# acceder a la informacion de las secuencias
sread(subset_fastq)

# acceder a la calidad de las secuencias
quality(subset_fastq)

# ver los valores numericos de la calidad
encoding(quality(subset_fastq))

# Escritura de fastq
writeFastq (subset_fastq, "raw_data/subset_antibodies.fastq")

####### Evaluacion de la Calidad de la secuenciacion 
# Ejercicio 15.
library(Rqc)
options(device.ask.default = FALSE)
qcRes <- rqc(path = "paired_reads", pattern = ".fastq", openBrowser=FALSE, pair = c(1,1))

# Informacion general de mis archivos
perFileInformation(qcRes)

# Distribucion de calidad media por lectura de archivos
rqcReadQualityBoxPlot(qcRes)

# Distribucion de calidad especifica del ciclo: boxplot
rqcCycleQualityBoxPlot(qcRes)

# Si solo queremos observar un archivo
rqcCycleQualityBoxPlot(qcRes[1])

# Podemos extraer la informacion de cada uno de los ciclos
lista_file1 <- rqcCycleQualityBoxPlot(qcRes[1])
str(lista_file1)
View(lista_file1$data)

#Proporción de llamada base específica del ciclo
rqcCycleBaseCallsLinePlot(qcRes)

# Solo de un archivo
rqcCycleBaseCallsLinePlot(qcRes[1])

# Frecuencias de lecturas
# Este grafico muestra la proporcian de lecturas que aparecieron muchas veces.
rqcReadFrequencyPlot(qcRes)

# Distribucion del tamaño de las lecturas
rqcReadWidthPlot(qcRes)

####### Filtrado y recorte de lecturas
# Ejercicio 16.
library(QuasR)
#Lectura de los archivos 
fastqFiles <- c("paired_reads/Cru1_S1_SED_R1.fastq", "paired_reads/Cru1_S1_SED_R2.fastq")

# Nombres de los archivos de salida
outfiles <-c("processed_data/processed_Cru1_S1_SED_R1.fastq", "processed_data/processed_Cru1_S1_SED_R2.fastq")

# Procesamiento de los archivos fastq 
# Quitar lecturas que tienen mas de 1 N (nBases)
# Cortar 3 bases del final de las lecturas (truncateEndBases)
# Quitar el patron "ACCCGGGA" si ocurre al principio (Lpattern)
# eliminar lecturas de menos de 280 pares de bases (minLength)
#
preprocessReads(fastqFiles, outfiles, 
                nBases=1,
                truncateEndBases=3,
                Lpattern="ACCCGGGA",
                minLength=280)

# leer archivo fastq
fastqFile <- system.file(package="ShortRead",
                         "extdata/E-MTAB-1147",
                         "ERR127302_1_subset.fastq.gz")
fq = readFastq(fastqFile)

# obtener puntajes de calidad por base en forma de una matriz
qPerBase = as(quality(fq), "matrix")

# obtener el numero de bases por lectura que tienen un puntaje de calidad inferior a 20
# usamos esto
qcount = rowSums( qPerBase <= 20) 

# Numero de lecturas en las que todas las puntuaciones de Phred >= 20
fq[qcount == 0]

#Escribimos fastq filtrado
writeFastq(fq[qcount == 0], "processed_data/ERR127302_1_subset_filterQ20.fastq.gz")


###########################
# Listado de Variables
ls()

# Informacion de la sesion
sessionInfo()
