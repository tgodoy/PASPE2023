##############################################################################
#########                          PASPE 2023                        #########
#########      Analisis de datos de Ciencias Genomicas usando R      #########   
#########    E. Ernestina Godoy Lozano (elizabeth.godoy@insp.mx)     #########
#########                    Bitacora de comandos                    #########
#########                     UNIDAD 3. METAGENOMICA                 #########
#########                 Analisis de alfa y beta diversidad         #########
##############################################################################

# Texto sin acentos

# Cargar librerias de trabajo

library(ggplot2)
library(vegan)
library(reshape2)
library(metagenomeSeq)
library(RColorBrewer)
library(phyloseq)
library(MASS)
library(FactoMineR)
library(factoextra)
library(ggpubr)

# Cargar funciones

getVDJrarefaction_sampling <- function (VDJinput, getTable = FALSE, file = NULL, IN_vector = TRUE, 
    clone_group = TRUE, maintitle = "VDJ Rarefaction Curve", muestreo= 1000) {
    if (IN_vector) {
        if (is.vector(VDJinput)) {
            idiotype <- VDJinput
        }
        else {
            stop("The VDJinput is not a vector and the IN_vector parameter is TRUE")
        }
    }
    else {
        idiotype <- apply(VDJinput, 1, function(input) {
            index <- grep(TRUE, is.na(input), value = FALSE)
            input[index] <- "Unclassified"
            index <- grep(" ", input, value = FALSE)
            input[index] <- "Unclassified"
            paste(input, collapse = "|")
        })
    }
    steps <- round(log(length(idiotype), base = 10))
    if (steps < 3) {
        steps <- as.numeric(paste("1", paste(rep(0, times = steps - 
            1), collapse = ""), sep = "", collapse = ""))
    }
    else {
        steps <- muestreo
    }
    samplesize <- steps
    total_groups <- t(table(idiotype))
    rarefaction <- NULL
    for (i in 1:length(idiotype)) {
        if (samplesize > length(idiotype)) {
            break
        }
        rarefaction <- rbind(rarefaction, c(samplesize, rarefy(total_groups, 
            samplesize)[1]))
        samplesize <- samplesize + steps
        i <- samplesize
    }
    if (getTable) {
        colnames(rarefaction) <- c("Reads_sampled", "No_clusters_captured")
        return(rarefaction)
    }
    else {
        if (!is.null(file)) 
            postscript(file = file, horizontal = FALSE, onefile = FALSE, 
                paper = "special", width = 7, height = 7)
        if (clone_group) {
            plot(rarefaction[, 1], rarefaction[, 2], ylab = "No of Clonal Groups captured", 
                xlab = "Reads sampled", type = "o", col = "blue", 
                main = maintitle)
        }
        else {
            plot(rarefaction[, 1], rarefaction[, 2], ylab = "No. of Idiotypes captured", 
                xlab = "Reads sampled", type = "o", col = "blue", 
                main = maintitle)
        }
        if (!is.null(file)) {
            dev.off()
        }
    }
}

# Funcion para poder unir columnas con diferente numero de filas
cbindPad <- function(...){
    args <- list(...)
    n <- sapply(args,nrow)
    mx <- max(n)
    pad <- function(x, mx){
        if (nrow(x) < mx){
            nms <- colnames(x)
            padTemp <- matrix(NA,mx - nrow(x), ncol(x))
            colnames(padTemp) <- nms
            return(rbind(x,padTemp))
        }
        else{
            return(x)
        }
    }
    rs <- lapply(args,pad,mx)
    return(do.call(cbind,rs))
}

### pairwise.adonis
pairwise.adonis <- function (x,factors, sim.function = 'vegdist', sim.method = 'bray', p.adjust.m ='bonferroni') {
	co = combn(unique(as.character(factors)),2)
	pairs = c()
	F.Model =c()
	R2 = c()
	p.value = c()
	
	for(elem in 1:ncol(co)){
		if(sim.function == 'daisy'){
			library(cluster); x1 = daisy(x[factors %in% c(co[1,elem],co[2,elem]),], metric=sim.method)
			} else {
				x1 = vegdist(x[factors %in% c(co[1,elem],co[2,elem]),], method=sim.method)
				}
				
	ad = adonis(x1 ~ factors[factors %in% c(co[1,elem],co[2,elem])] );
	pairs = c(pairs,paste(co[1,elem],'vs',co[2,elem]));
	F.Model =c(F.Model,ad$aov.tab[1,4]);
	R2 = c(R2,ad$aov.tab[1,5]);
	p.value = c(p.value,ad$aov.tab[1,6])
	}
	p.adjusted = p.adjust(p.value,method=p.adjust.m)
	sig = c(rep('',length(p.adjusted)))
	sig[p.adjusted <= 0.05] <-'*'
	sig[p.adjusted <= 0.01] <-'**'
	sig[p.adjusted <= 0.001] <-'***'
	sig[p.adjusted <= 0.0001] <-'****'
	
	pairw.res = data.frame(pairs,F.Model,R2,p.value,p.adjusted,sig)
	print("Signif. codes:  0 '****' 0.001 '***' 0.01 '**' 0.05 '*' 0.1 '+' 1")
	return(pairw.res)
}


### Posicionarme en mi espacio de trabajo
getwd()
setwd("~/PASPE_2023_Datos_genomicos_R/5.Metagenomica_Alfa_beta_diversidad")


### Cargar datos de entrada

### Ejercicio 1. Calculo de los estimadores de alfa diversidad
# Leer los datos de entrada
abun_table <- read.delim("tablas/Genus.txt", header=T, row.names=1)
variables <- read.delim("tablas/abiotic_variables.txt", header=T, row.names=1)

abun_table_mat <- as.matrix(abun_table)
dim(abun_table)
View(abun_table)

taxrank_mat <- as.matrix(rownames(abun_table_mat))
colnames(taxrank_mat) <- ("TAX")
rownames(taxrank_mat) <- rownames(abun_table_mat)
head(taxrank_mat)

# Generar objetos necesarios phyloseq con las funciones de phyloseq especificas
# 1.Matriz de OTUs (En nuestro caso es la matriz de Generos)
OTU <- otu_table(abun_table_mat, taxa_are_rows=TRUE)

# 2.Una matriz con las anotaciones de los OTUS (En nuestro caso es la anotacion taxonomica a nivel de genero)
TAX <- tax_table(taxrank_mat)

# 3. Cargar tabla de metadatos
MET <- sample_data(variables)

# 4.Construimos nuestro objeto de phyloseq
physeq <- phyloseq(OTU, TAX, MET)
str(physeq)

# 5. Obtenemos los indices de diversidad y los colocamos en una tabla
diversity_index <- data.frame(round(estimate_richness(physeq, measures=c("Observed", "Chao1", "Shannon", "Simpson")), 2))
diversity_index

# 6. Escribimos la tabla
write.table(diversity_index, "tablas/alpha_diversity_index.txt", quote = FALSE, sep = "\t", row.names = TRUE, col.names=TRUE)

# 7. Generar boxplot de Shannon
# Agregar columna de Condicion a la tabla diversity_index

diversity_index$Clase <- sapply(as.character(rownames(diversity_index)), 
                                function(x){strsplit(x, "_")[[1]][1]})

ggboxplot(diversity_index, x="Clase", y="Shannon",
          color = "Clase",
          palette =c("#00AFBB", "#E7B800", "#FC4E07"),
          add="jitter",
          ylab = "Shannon index",
          xlab = "")
ggsave("figuras/boxplot_shannon.png", device = "png", dpi = 300, units = "px", bg = "white")

# Generacion de un archivo de tipo phyloseq con qiime2R
# Cargar librerias de trabajo
library(qiime2R)
library(tidyverse)

physeq_qiime2 <- qza_to_phyloseq (
  features="qiime2/table.qza",
  tree="qiime2/rooted-tree.qza",
  taxonomy="qiime2/taxonomy_blast.qza",
  metadata = "qiime2/metadata.tsv")

physeq_qiime2
class(physeq_qiime2)
str(physeq_qiime2)

diversity_index2 <- data.frame(round(estimate_richness(physeq_qiime2, measures=c("Observed", "Chao1", "Shannon", "Simpson")), 2))
diversity_index2

### Ejercicio 2. Generar grafica de rarefaccion.
head(abun_table)

# 1.Determinar un numero de muestreo fijo (secuencias). En este caso seran 1000 secuencias
muestreo <- 1000

DF <-data.frame("Sampling"=c(1000,2000,3000,4000))

for (i in 1:dim(abun_table)[2]){
	muestra <- colnames(abun_table)[i]
	columna <- data.frame(abun_table[,i])
	rownames(columna) <- rownames(abun_table)
	colnames(columna) <- "abund"
	new_tabla <- data.frame()
	for (j in 1:dim(columna)[1]){
		taxa <- data.frame(taxas=rep(rownames(columna)[j], columna$abund[j]))
		new_tabla <- rbind(new_tabla, taxa)
	}
	tabla_rarefaction <- getVDJrarefaction_sampling(as.character(new_tabla$taxas), getTable=TRUE, file=NULL, muestreo=muestreo)
	tabla_corta <- as.data.frame(tabla_rarefaction[,2])
	colnames(tabla_corta) <- muestra
	DF <- cbindPad(DF, tabla_corta)
	print(paste("Acabo de terminar la muestra ",muestra, " ", i ,"/", dim(abun_table)[2], sep=""))
}

# Completar el muestreo correcto
tamagno <- dim(DF)[1]
DF$Sampling <-seq(muestreo, muestreo*tamagno, muestreo) 
head(DF)
tail(DF)
dim(DF)

# Transformar nuestro data frame en una matrix
transf_DF <- as.matrix(DF[,-1])
rownames(transf_DF) <- DF[,1]

# Contraer la informacion de la matriz para generar la grafica
DF_melt <- melt(transf_DF)
dim(DF_melt)
View(DF_melt)
# Quitar valores que tienen NAs
nas <- which(is.na(DF_melt$value))
DF_melt <- DF_melt[-nas,]

### Generar vectores de colores para cada muestra
# Generare 5 colores de cada paleta con la funcion colorRampPalette en formato RGB
read <- colorRampPalette(c("#F4543E", "#A2200E"), space = "rgb")(5) # Costa
green <- colorRampPalette(c("#73E741", "#2A7808"), space = "rgb")(5) # Someras
blue <- colorRampPalette(c("#1ADFF7", "#086C78"), space = "rgb")(5) # Profundas

colors <- c(read, green, blue)

# Generar grafica
ggplot(DF_melt, aes(x= Var1, y=value, group= Var2, color= Var2)) + 
	geom_line() + geom_point() + 
	theme(axis.text.x = element_text(angle=30, hjust=1, vjust=1)) + 
	labs(x="Sample size (Reads)", y="Number of Genus", colour= "Samples") + 
	theme_bw() + scale_color_manual(values= colors)

# Generar imagen
ggplot(DF_melt, aes(x= Var1, y=value, group= Var2, color= Var2)) + 
	geom_line() + geom_point() + 
	theme(axis.text.x = element_text(angle=30, hjust=1, vjust=1)) + 
	labs(x="Sample size (Reads)", y="Number of Genus", colour= "Samples") + 
	theme_bw() + scale_color_manual(values= colors)
ggsave("figuras/rarefaction_genus.png", device ="png", dpi = 300)

###   Ejercicio 3: Generacion de PCoA/NMDS con phyloseq 

# Generacion del PCoA con el metodo de Bray-Curtis ussando la funcion "ordinate()"
ordination <- ordinate(physeq, "PCoA", "bray")
plot_ordination(physeq, ordination, color="grupo")

# Podemos usar la informacion de alguna variable continua
plot_ordination(physeq, ordination, color="Deep")

# Cambiarle el color a otra paleta de colores
plot_ordination(physeq, ordination, color="Deep") + 
  scale_colour_gradientn(colours= topo.colors(10))

# Vamos a usar la sintaxis de ggplot2 para mejorar las graficas
plot_ordination(physeq, ordination, color="grupo") + 
  stat_ellipse() +
  scale_color_manual(values= c("deeppink1", "darkturquoise", "gold")) +
  labs(title="PCoA") + theme_bw()

# Ejemplo de como generar un PCoA cuando tenemos la informacion 
# del arbol filogenetico
plot_ordination(physeq_qiime2, 
                ordinate(physeq_qiime2, "PCoA", "wunifrac"), 
                color="Type")

# Guardar nuestro grafico
plot_ordination(physeq, ordination, color="grupo") + stat_ellipse() +
  scale_color_manual(values= c("deeppink1", "darkturquoise", "gold")) +
  labs(title="PCoA") + theme_bw()
ggsave("figuras/PCoA_bray_points_phyloseq.png", device = "png", dpi = 300, units = "px")

# Ejemplo de como generar un NMDS 
plot_ordination(physeq, ordinate(physeq, "NMDS", "bray"), color="grupo") +
  scale_color_manual(values= c("deeppink1", "darkturquoise", "gold")) +
  labs(title="NMDS") + theme_bw()
ggsave("figuras/NMDS_bray_points_phyloseq.png", device = "png", dpi = 300, units = "px")


### Ejercicio extra. Generacion de NMDS con matriz normalizada 
# por Metagenomeseq agrupando por grupos.
# Normalizar usando el metodo de metagenomeSeq. 
# 1. Cargar matriz de conteos absolutos
datos <- loadMeta("tablas/Genus.txt")

# 2.Transformarla a un objeto de metagenomeSeq llamado "MRexperiment"
MRexp <- newMRexperiment(datos$counts)

# 3.Calcular el percentil para el cual sumar los conteos absolutos
p <- cumNormStatFast(MRexp)

# 4.Normalizamos la matriz 
normalized_matrix <- cumNormMat(MRexp, p = p)
head(normalized_matrix)

# 5.Escribimos la matriz normalizada
exportMat(normalized_matrix, file ="tablas/normal_Genus.txt")

# Generar NMDS
# 1.Transponer la matriz normalizada para que las filas sean las muestras y los taxa las columnas
transp_mat <- t(normalized_matrix)
View(transp_mat)

# 2.Generamos el NMDS con la funcion metaMDS de vegan con una matriz de distancia con el metodo de Bray-curtis y lo aplicamos a 2 dimensiones (k=2)
nmds <- vegan::metaMDS(transp_mat, distance = "bray", k = 2, trace = FALSE)
nmds

# 3.Guardamos el valor de stress en una variable
var_stress <- round(nmds$stress, 10)
var_stress

# 4.Generar grupos para el NMDS
View(transp_mat)

muestras <- data.frame(estacion=rownames(transp_mat))
muestras$clase <- sapply(as.character(muestras$estacion), function(x){strsplit(x, "_")[[1]][1]})
muestras$color <- "coral1"
muestras$color[which(muestras$clase=="Someras")] <- "seagreen2"
muestras$color[which(muestras$clase=="Profundas")] <- "deepskyblue"

# Guardar los valores en un objeto
grupos <- muestras$clase
colores <- muestras$color
estaciones <- muestras$estacion

# Generar plot
plot(nmds, type = "n", cex.lab=0.7, cex.axis=0.7)
points(nmds, col= colores, pch=19)
ordiellipse(nmds, grupos, display = "sites", kind = "sd", conf = 0.9, label =T, col=c("coral1", "deepskyblue", "seagreen2"), cex=0.7)
coord <- par("usr")
text(coord[1]+0.4, coord[3]+0.1, labels=paste("Stress: ", var_stress, sep=''), cex=0.7)
#text(nmds, labels = estaciones , cex=0.6, col= colores)
legend("topright", legend=c("Costa", "Profundas", "Someras"), pch=16, col=c("coral1", "deepskyblue", "seagreen2"), border="white", bty="n", cex=0.7)

# Guardar imagen
png("figuras/NMDS_bray_points.png", width = 5*300, height = 5*300, res = 300, pointsize = 8, units= "px")
plot(nmds, type = "n", cex.lab=0.7, cex.axis=0.7)
points(nmds, col= colores, pch=19)
ordiellipse(nmds, grupos, display = "sites", kind = "sd", conf = 0.9, label =T, col=c("coral1", "deepskyblue", "seagreen2"), cex=0.7)
coord <- par("usr")
text(coord[1]+0.2, coord[3]+0.1, labels=paste("Stress: ", var_stress, sep=''), cex=0.7)
#text(nmds, labels = estaciones , cex=0.6, col= colores)
legend("topright", legend=c("Costa", "Profundas", "Someras"), pch=16, col=c("coral1", "deepskyblue", "seagreen2"), border="white", bty="n", cex=0.7)
dev.off()


#### Ejercicio 5. ANOSIM y ADONIS.

# ANOSIM (Diferencias entre todos los grupos)
View(transp_mat)
resultado_anosim <- anosim(transp_mat, grouping= grupos, permutations = 999, distance = "bray")
resultado_anosim

# ADONIS pareado (comparacion pareada de los grupos)
resultado_adonis <- pairwise.adonis(x= transp_mat, grupos, sim.function = 'vegdist', sim.method='bray', p.adjust.m='bonferroni')
resultado_adonis

### Ejercicio 5. Principal Component Analysis
# Cargar datos
variables <- read.delim("tablas/abiotic_variables.txt", header=T, row.names=1)
dim(variables)
head(variables)
head(muestras)

# PCA basico
# Quitar la columna de los grupos
pca <- prcomp(variables[,-36], scale=T)
summary(pca)

# Generar pdf con las imagenes
pdf("figuras/PCA_basico.pdf")
plot(pca)
biplot(pca)
dev.off()

# PCA mas complejo usando la funcion PCA de FactoMineR
# Sin grupos
pca_graficar <- PCA(variables[,-36])

# Con grupos
# Usar la columna con los datos de los grupos
head(variables)
View(variables)
dim(variables)
pca_graficar <- PCA(variables, quali.sup=dim(variables)[2]) 

# Graficar el PCA con la funcion de plot()
options(ggrepel.max.overlaps = Inf)
plot(pca_graficar, habillage = dim(variables)[2], col.hab = c("coral1", "deepskyblue", "seagreen2"))

# Usar funciones especializadas de FactoMineR
fviz_eig(pca_graficar, addlabels = TRUE, ylim = c(0, 50))
fviz_pca_var(pca_graficar, col.var="contrib")
fviz_pca_ind(pca_graficar, habillage= dim(variables)[2], addEllipses=TRUE, ellipse.level=0.9) + theme_minimal()
fviz_pca_biplot(pca_graficar, label="ind", col.ind = variables$grupo, addEllipses=F)
fviz_pca_biplot(pca_graficar, label="var", col.ind =variables$grupo, addEllipses=F, labelsize = 3, col.var="gray") 
fviz_pca_biplot(pca_graficar, label="all", col.ind =variables$grupo, addEllipses=F, labelsize = 3, col.var="gray") 

# Contribuciones de las variables al componente 1 (PC1)
fviz_contrib(pca_graficar, choice = "var", axes = 1, top = 10)
# Contribuciones de las variables al componente 2 (PC2)
fviz_contrib(pca_graficar, choice = "var", axes = 2, top = 10)

# Generar imagenes en un pdf
pdf("figuras/PCA_complejo.pdf")
fviz_pca_biplot(pca_graficar, label="all", col.ind =variables$grupo, addEllipses=T, labelsize = 3, col.var="gray", ellipse.level=0.9) +
	scale_color_manual(values= c("coral1", "deepskyblue", "seagreen2")) +
	scale_fill_manual(values= c("coral1", "deepskyblue", "seagreen2"))
fviz_pca_var(pca_graficar, col.var="contrib") + scale_colour_gradientn(colours = topo.colors(10))
fviz_eig(pca_graficar, addlabels = TRUE, ylim = c(0, 50), barcolor ="dodgerblue4", barfill= "dodgerblue2")
fviz_contrib(pca_graficar, choice = "var", axes = 1, top = 10)
fviz_contrib(pca_graficar, choice = "var", axes = 2, top = 10)
dev.off()

## Listar objetos generados
ls()

## Informacion de la sesion
sessionInfo()